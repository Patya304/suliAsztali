﻿namespace _2025._2._27
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_Add = new System.Windows.Forms.TextBox();
            this.lb1 = new System.Windows.Forms.ListBox();
            this.btn_Add = new System.Windows.Forms.Button();
            this.btn_Top = new System.Windows.Forms.Button();
            this.btn_Up = new System.Windows.Forms.Button();
            this.btn_down = new System.Windows.Forms.Button();
            this.btn_pince = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txt_Add
            // 
            this.txt_Add.Location = new System.Drawing.Point(33, 39);
            this.txt_Add.Name = "txt_Add";
            this.txt_Add.Size = new System.Drawing.Size(168, 20);
            this.txt_Add.TabIndex = 0;
            // 
            // lb1
            // 
            this.lb1.FormattingEnabled = true;
            this.lb1.Location = new System.Drawing.Point(33, 68);
            this.lb1.Name = "lb1";
            this.lb1.Size = new System.Drawing.Size(168, 316);
            this.lb1.TabIndex = 1;
            // 
            // btn_Add
            // 
            this.btn_Add.Location = new System.Drawing.Point(207, 37);
            this.btn_Add.Name = "btn_Add";
            this.btn_Add.Size = new System.Drawing.Size(75, 23);
            this.btn_Add.TabIndex = 2;
            this.btn_Add.Text = "Hozzáad";
            this.btn_Add.UseVisualStyleBackColor = true;
            // 
            // btn_Top
            // 
            this.btn_Top.Location = new System.Drawing.Point(215, 128);
            this.btn_Top.Name = "btn_Top";
            this.btn_Top.Size = new System.Drawing.Size(58, 23);
            this.btn_Top.TabIndex = 4;
            this.btn_Top.Text = "Felülre";
            this.btn_Top.UseVisualStyleBackColor = true;
            this.btn_Top.Click += new System.EventHandler(this.btn_Top_Click);
            // 
            // btn_Up
            // 
            this.btn_Up.Location = new System.Drawing.Point(215, 157);
            this.btn_Up.Name = "btn_Up";
            this.btn_Up.Size = new System.Drawing.Size(58, 23);
            this.btn_Up.TabIndex = 5;
            this.btn_Up.Text = "Fel";
            this.btn_Up.UseVisualStyleBackColor = true;
            // 
            // btn_down
            // 
            this.btn_down.Location = new System.Drawing.Point(215, 186);
            this.btn_down.Name = "btn_down";
            this.btn_down.Size = new System.Drawing.Size(58, 23);
            this.btn_down.TabIndex = 6;
            this.btn_down.Text = "Le";
            this.btn_down.UseVisualStyleBackColor = true;
            // 
            // btn_pince
            // 
            this.btn_pince.Location = new System.Drawing.Point(215, 215);
            this.btn_pince.Name = "btn_pince";
            this.btn_pince.Size = new System.Drawing.Size(58, 23);
            this.btn_pince.TabIndex = 7;
            this.btn_pince.Text = "Alulra";
            this.btn_pince.UseVisualStyleBackColor = true;
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(215, 361);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(58, 23);
            this.btn_delete.TabIndex = 8;
            this.btn_delete.Text = "Töröl";
            this.btn_delete.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_pince);
            this.Controls.Add(this.btn_down);
            this.Controls.Add(this.btn_Up);
            this.Controls.Add(this.btn_Top);
            this.Controls.Add(this.btn_Add);
            this.Controls.Add(this.lb1);
            this.Controls.Add(this.txt_Add);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_Add;
        private System.Windows.Forms.ListBox lb1;
        private System.Windows.Forms.Button btn_Add;
        private System.Windows.Forms.Button btn_Top;
        private System.Windows.Forms.Button btn_Up;
        private System.Windows.Forms.Button btn_down;
        private System.Windows.Forms.Button btn_pince;
        private System.Windows.Forms.Button btn_delete;
    }
}

