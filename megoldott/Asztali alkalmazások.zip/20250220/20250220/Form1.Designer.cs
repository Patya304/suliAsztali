﻿namespace _20250220
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Title = new System.Windows.Forms.Label();
            this.tB_itemName = new System.Windows.Forms.TextBox();
            this.itemSearch = new System.Windows.Forms.Label();
            this.cmb_Category = new System.Windows.Forms.ComboBox();
            this.Text2 = new System.Windows.Forms.Label();
            this.btn_Add = new System.Windows.Forms.Button();
            this.lb_items = new System.Windows.Forms.ListBox();
            this.Text3 = new System.Windows.Forms.Label();
            this.btn_Remove = new System.Windows.Forms.Button();
            this.cb_allItemRemove = new System.Windows.Forms.CheckBox();
            this.rb_Elelmiszer = new System.Windows.Forms.RadioButton();
            this.Text4 = new System.Windows.Forms.Label();
            this.rb_Haztartas = new System.Windows.Forms.RadioButton();
            this.rb_Elektronika = new System.Windows.Forms.RadioButton();
            this.btn_Filter = new System.Windows.Forms.Button();
            this.btn_Save = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Title
            // 
            this.Title.AutoSize = true;
            this.Title.Location = new System.Drawing.Point(128, 21);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(72, 13);
            this.Title.TabIndex = 0;
            this.Title.Text = "Bevásárlólista";
            this.Title.Click += new System.EventHandler(this.Title_Click);
            // 
            // tB_itemName
            // 
            this.tB_itemName.Location = new System.Drawing.Point(15, 88);
            this.tB_itemName.Name = "tB_itemName";
            this.tB_itemName.Size = new System.Drawing.Size(100, 20);
            this.tB_itemName.TabIndex = 1;
            this.tB_itemName.TextChanged += new System.EventHandler(this.tB_itemName_TextChanged);
            // 
            // itemSearch
            // 
            this.itemSearch.AutoSize = true;
            this.itemSearch.Location = new System.Drawing.Point(12, 62);
            this.itemSearch.Name = "itemSearch";
            this.itemSearch.Size = new System.Drawing.Size(139, 13);
            this.itemSearch.TabIndex = 2;
            this.itemSearch.Text = "Adjon meg egy terméknevet";
            // 
            // cmb_Category
            // 
            this.cmb_Category.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_Category.FormattingEnabled = true;
            this.cmb_Category.Items.AddRange(new object[] {
            "Élelmiszer",
            "Háztartás",
            "Elektronika"});
            this.cmb_Category.Location = new System.Drawing.Point(15, 151);
            this.cmb_Category.Name = "cmb_Category";
            this.cmb_Category.Size = new System.Drawing.Size(121, 21);
            this.cmb_Category.TabIndex = 3;
            this.cmb_Category.SelectedIndexChanged += new System.EventHandler(this.cmb_Category_SelectedIndexChanged);
            // 
            // Text2
            // 
            this.Text2.AutoSize = true;
            this.Text2.Location = new System.Drawing.Point(12, 125);
            this.Text2.Name = "Text2";
            this.Text2.Size = new System.Drawing.Size(128, 13);
            this.Text2.TabIndex = 4;
            this.Text2.Text = "Válasz a kategóriák közül";
            // 
            // btn_Add
            // 
            this.btn_Add.Location = new System.Drawing.Point(15, 193);
            this.btn_Add.Name = "btn_Add";
            this.btn_Add.Size = new System.Drawing.Size(75, 23);
            this.btn_Add.TabIndex = 5;
            this.btn_Add.Text = "Hozzáadás";
            this.btn_Add.UseVisualStyleBackColor = true;
            this.btn_Add.Click += new System.EventHandler(this.btn_Add_Click);
            // 
            // lb_items
            // 
            this.lb_items.FormattingEnabled = true;
            this.lb_items.Location = new System.Drawing.Point(12, 270);
            this.lb_items.Name = "lb_items";
            this.lb_items.Size = new System.Drawing.Size(120, 82);
            this.lb_items.TabIndex = 6;
            this.lb_items.SelectedIndexChanged += new System.EventHandler(this.lb_items_SelectedIndexChanged);
            // 
            // Text3
            // 
            this.Text3.AutoSize = true;
            this.Text3.Location = new System.Drawing.Point(12, 243);
            this.Text3.Name = "Text3";
            this.Text3.Size = new System.Drawing.Size(83, 13);
            this.Text3.TabIndex = 7;
            this.Text3.Text = "Eddigi termékek";
            // 
            // btn_Remove
            // 
            this.btn_Remove.Location = new System.Drawing.Point(12, 381);
            this.btn_Remove.Name = "btn_Remove";
            this.btn_Remove.Size = new System.Drawing.Size(75, 23);
            this.btn_Remove.TabIndex = 8;
            this.btn_Remove.Text = "Törlés";
            this.btn_Remove.UseVisualStyleBackColor = true;
            this.btn_Remove.Click += new System.EventHandler(this.btn_Remove_Click);
            // 
            // cb_allItemRemove
            // 
            this.cb_allItemRemove.AutoSize = true;
            this.cb_allItemRemove.Location = new System.Drawing.Point(93, 385);
            this.cb_allItemRemove.Name = "cb_allItemRemove";
            this.cb_allItemRemove.Size = new System.Drawing.Size(94, 17);
            this.cb_allItemRemove.TabIndex = 9;
            this.cb_allItemRemove.Text = "Összes törlése";
            this.cb_allItemRemove.UseVisualStyleBackColor = true;
            this.cb_allItemRemove.CheckedChanged += new System.EventHandler(this.cb_allItemRemove_CheckedChanged);
            // 
            // rb_Elelmiszer
            // 
            this.rb_Elelmiszer.AutoSize = true;
            this.rb_Elelmiszer.Location = new System.Drawing.Point(223, 270);
            this.rb_Elelmiszer.Name = "rb_Elelmiszer";
            this.rb_Elelmiszer.Size = new System.Drawing.Size(71, 17);
            this.rb_Elelmiszer.TabIndex = 10;
            this.rb_Elelmiszer.TabStop = true;
            this.rb_Elelmiszer.Text = "Élelmiszer";
            this.rb_Elelmiszer.UseVisualStyleBackColor = true;
            // 
            // Text4
            // 
            this.Text4.AutoSize = true;
            this.Text4.Location = new System.Drawing.Point(220, 243);
            this.Text4.Name = "Text4";
            this.Text4.Size = new System.Drawing.Size(94, 13);
            this.Text4.TabIndex = 11;
            this.Text4.Text = "Termékek szűrése";
            // 
            // rb_Haztartas
            // 
            this.rb_Haztartas.AutoSize = true;
            this.rb_Haztartas.Location = new System.Drawing.Point(223, 293);
            this.rb_Haztartas.Name = "rb_Haztartas";
            this.rb_Haztartas.Size = new System.Drawing.Size(70, 17);
            this.rb_Haztartas.TabIndex = 12;
            this.rb_Haztartas.TabStop = true;
            this.rb_Haztartas.Text = "Háztartás";
            this.rb_Haztartas.UseVisualStyleBackColor = true;
            // 
            // rb_Elektronika
            // 
            this.rb_Elektronika.AutoSize = true;
            this.rb_Elektronika.Location = new System.Drawing.Point(223, 316);
            this.rb_Elektronika.Name = "rb_Elektronika";
            this.rb_Elektronika.Size = new System.Drawing.Size(78, 17);
            this.rb_Elektronika.TabIndex = 13;
            this.rb_Elektronika.TabStop = true;
            this.rb_Elektronika.Text = "Elektronika";
            this.rb_Elektronika.UseVisualStyleBackColor = true;
            // 
            // btn_Filter
            // 
            this.btn_Filter.Location = new System.Drawing.Point(223, 349);
            this.btn_Filter.Name = "btn_Filter";
            this.btn_Filter.Size = new System.Drawing.Size(75, 23);
            this.btn_Filter.TabIndex = 14;
            this.btn_Filter.Text = "Szűrés";
            this.btn_Filter.UseVisualStyleBackColor = true;
            this.btn_Filter.Click += new System.EventHandler(this.btn_Filter_Click);
            // 
            // btn_Save
            // 
            this.btn_Save.Location = new System.Drawing.Point(223, 426);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(75, 23);
            this.btn_Save.TabIndex = 15;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = true;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(339, 533);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.btn_Filter);
            this.Controls.Add(this.rb_Elektronika);
            this.Controls.Add(this.rb_Haztartas);
            this.Controls.Add(this.Text4);
            this.Controls.Add(this.rb_Elelmiszer);
            this.Controls.Add(this.cb_allItemRemove);
            this.Controls.Add(this.btn_Remove);
            this.Controls.Add(this.Text3);
            this.Controls.Add(this.lb_items);
            this.Controls.Add(this.btn_Add);
            this.Controls.Add(this.Text2);
            this.Controls.Add(this.cmb_Category);
            this.Controls.Add(this.itemSearch);
            this.Controls.Add(this.tB_itemName);
            this.Controls.Add(this.Title);
            this.Name = "Form1";
            this.Text = "Bevásárlólista";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Title;
        private System.Windows.Forms.TextBox tB_itemName;
        private System.Windows.Forms.Label itemSearch;
        private System.Windows.Forms.ComboBox cmb_Category;
        private System.Windows.Forms.Label Text2;
        private System.Windows.Forms.Button btn_Add;
        private System.Windows.Forms.ListBox lb_items;
        private System.Windows.Forms.Label Text3;
        private System.Windows.Forms.Button btn_Remove;
        private System.Windows.Forms.CheckBox cb_allItemRemove;
        private System.Windows.Forms.RadioButton rb_Elelmiszer;
        private System.Windows.Forms.Label Text4;
        private System.Windows.Forms.RadioButton rb_Haztartas;
        private System.Windows.Forms.RadioButton rb_Elektronika;
        private System.Windows.Forms.Button btn_Filter;
        private System.Windows.Forms.Button btn_Save;
    }
}

