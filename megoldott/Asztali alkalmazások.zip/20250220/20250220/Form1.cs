﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace _20250220
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Title_Click(object sender, EventArgs e)
        {

        }

        private void btn_Add_Click(object sender, EventArgs e)
        {
            if (tB_itemName.Text == "")
            {
                MessageBox.Show("Kérlek add meg termék a nevét");
            }
            else if (cmb_Category.SelectedIndex == -1)
            {   
                MessageBox.Show("Válasz kategóriát!");
            }
            else if (File.Exists("termekek.txt"))
            {
                File.AppendAllText("termekek.txt", tB_itemName.Text + ";" + cmb_Category.SelectedItem.ToString() + "\n");
            }
            else
            {
                File.WriteAllText("termekek.txt", tB_itemName.Text + ";" + cmb_Category.SelectedItem.ToString() + "\n");
            }
        }

        private void tB_itemName_TextChanged(object sender, EventArgs e)
        {

        }

        private void cmb_Category_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (File.Exists("termekek.txt"))
            {
                string[] beolvas = File.ReadAllLines("termekek.txt");
                lb_items.Items.AddRange(beolvas);
            }
        }

        private void lb_items_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btn_Remove_Click(object sender, EventArgs e)
        {
            if (cb_allItemRemove.Checked)
            {
                lb_items.Items.Clear();
            }
            else
            {
                lb_items.Items.RemoveAt(lb_items.SelectedIndex);
            }
        }

        private void cb_allItemRemove_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            
        }

        private void btn_Filter_Click(object sender, EventArgs e)
        {
            if (cmb_Category.Text != "")
            {
                List<string> eredeti = new List<string>();
                foreach (var item in lb_items.Items)
                {
                    eredeti.Add(item.ToString());
                }

                List<string> filter = new List<string>();
                foreach (var item in lb_items.Items)
                {
                    if (item.ToString().Contains(cmb_Category.Text))
                    {
                        filter.Add(item.ToString());
                    } 
                }
                lb_items.Items.Clear();
                foreach (var item in filter)
                {
                    lb_items.Items.Add(item);
                }
            }
            else
            {
                MessageBox.Show("Válassz kategóriát!");
            }
        }
    }
}
