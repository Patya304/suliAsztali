﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace _20250205
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txt_tippMix_TextChanged(object sender, EventArgs e)
        {
            string desc = txt_tippMix.Text;
            if (desc.Trim() == "")
            {
                lbl_Db.Text = $"{0} db";
            }
            else
            {
                int db = desc.Trim().Split(' ').Length;
                lbl_Db.Text = $"{db} db";

                if (int.Parse(desc.Trim().Split(' ')[db-1])>99 || int.Parse(desc.Trim().Split(' ')[db-1]) <1)
                {
                    MessageBox.Show("Nem megfelelő a tartomány!", "Hiba!");
                }
                if (db > 4)
                {
                    btn_Add.Enabled = false;
                    MessageBox.Show("A tippek száma nem mefelelő!", "Hiba!");
                }
                else
                {
                    btn_Add.Enabled = true;
                }
            }
        }

        private void lbl_Db_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn_Add_Click(object sender, EventArgs e)
        {
            if (File.Exists("tippek.txt"))
            {
                if (File.ReadAllText("tippek.txt").Contains(txt_plyer.Text))
                {
                    MessageBox.Show("Van már ilyen nevű játékos", "Hiba!");
                }
                else
                {
                    string nev = txt_plyer.Text.Trim();
                    string tipp = txt_tippMix.Text.Trim();
                    //string print = nev + ' ' + tipp;
                    //File.AppendAllText("tippek.txt", print);
                    string[] beolvas = File.ReadAllLines("tippek.txt");
                    List<string> print = new List<string>();
                    foreach (var item in beolvas)
                    {
                        print.Add(item);
                    }
                    print.Add(nev + ' ' + tipp);
                    File.WriteAllLines("tippek.txt", print);
                }
            }
            else
            {
                string nev = txt_plyer.Text.Trim();
                string tipp = txt_tippMix.Text.Trim();
                string print = nev + ' ' + tipp;
                File.AppendAllText("tippek.txt", print);
            }
        }
    }
}
