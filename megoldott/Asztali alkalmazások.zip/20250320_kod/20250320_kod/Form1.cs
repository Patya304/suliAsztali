﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _20250320_kod
{
    public partial class Form1 : Form
    {
        private Random rand;
        private int secretCode;
        public Form1()
        {
            InitializeComponent();
            rand = new Random();
            GenerateSecretCode();
        }
        private void GenerateSecretCode()
        {
            secretCode = rand.Next(1000, 10000);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void tb_trying_TextChanged(object sender, EventArgs e)
        {
        }

        private void lb_correct_nums_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void btn_check_Click(object sender, EventArgs e)
        {
            string input = tb_trying.Text;
            if (input.Length != 4)
            {
                MessageBox.Show("Kérlek, adj meg egy 4 jegyű számot!");
            }

            int correctDigits = 0;
            for (int i = 0; i < 4; i++)
            {
                if (input[i] == secretCode.ToString()[i])
                {
                    correctDigits++;
                }
            }

            lb_correct_nums.Items.Add($"Próba: {input} - Helyes számjegyek: {correctDigits}");

            if (correctDigits == 4)
            {
                {
                    MessageBox.Show("Grat! Megfejtetted a kódot!");
                    secretCode = rand.Next(1000, 10000);
                }
            }
        }
    }
}