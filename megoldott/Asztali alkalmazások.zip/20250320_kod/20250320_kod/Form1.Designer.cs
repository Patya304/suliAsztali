﻿namespace _20250320_kod
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_trying = new System.Windows.Forms.TextBox();
            this.lb_correct_nums = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_check = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tb_trying
            // 
            this.tb_trying.Location = new System.Drawing.Point(12, 52);
            this.tb_trying.Name = "tb_trying";
            this.tb_trying.Size = new System.Drawing.Size(100, 20);
            this.tb_trying.TabIndex = 0;
            this.tb_trying.TextChanged += new System.EventHandler(this.tb_trying_TextChanged);
            // 
            // lb_correct_nums
            // 
            this.lb_correct_nums.FormattingEnabled = true;
            this.lb_correct_nums.Location = new System.Drawing.Point(204, 52);
            this.lb_correct_nums.Name = "lb_correct_nums";
            this.lb_correct_nums.Size = new System.Drawing.Size(301, 498);
            this.lb_correct_nums.TabIndex = 1;
            this.lb_correct_nums.SelectedIndexChanged += new System.EventHandler(this.lb_correct_nums_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(152, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Próbálkozz, 4 jegyű számokkal";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(201, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Eltalált számok";
            // 
            // btn_check
            // 
            this.btn_check.Location = new System.Drawing.Point(12, 104);
            this.btn_check.Name = "btn_check";
            this.btn_check.Size = new System.Drawing.Size(75, 23);
            this.btn_check.TabIndex = 4;
            this.btn_check.Text = "Ellenőrzés";
            this.btn_check.UseVisualStyleBackColor = true;
            this.btn_check.Click += new System.EventHandler(this.btn_check_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(537, 566);
            this.Controls.Add(this.btn_check);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lb_correct_nums);
            this.Controls.Add(this.tb_trying);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tb_trying;
        private System.Windows.Forms.ListBox lb_correct_nums;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_check;
    }
}

