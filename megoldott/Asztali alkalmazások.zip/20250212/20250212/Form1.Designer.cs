﻿namespace _20250212
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonExit = new System.Windows.Forms.Button();
            this.radioCukor = new System.Windows.Forms.CheckBox();
            this.radioMilk = new System.Windows.Forms.CheckBox();
            this.radioIce = new System.Windows.Forms.CheckBox();
            this.radioTea = new System.Windows.Forms.RadioButton();
            this.radioCoffe = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.buttonPay = new System.Windows.Forms.Button();
            this.radioSzörp = new System.Windows.Forms.CheckBox();
            this.checkCitrom = new System.Windows.Forms.CheckBox();
            this.radioWater = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // buttonExit
            // 
            this.buttonExit.Location = new System.Drawing.Point(700, 288);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(75, 23);
            this.buttonExit.TabIndex = 0;
            this.buttonExit.Text = "Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // radioCukor
            // 
            this.radioCukor.AutoSize = true;
            this.radioCukor.Location = new System.Drawing.Point(146, 66);
            this.radioCukor.Name = "radioCukor";
            this.radioCukor.Size = new System.Drawing.Size(54, 17);
            this.radioCukor.TabIndex = 1;
            this.radioCukor.Text = "Cukor";
            this.radioCukor.UseVisualStyleBackColor = true;
            this.radioCukor.CheckedChanged += new System.EventHandler(this.radioCukor_CheckedChanged);
            // 
            // radioMilk
            // 
            this.radioMilk.AutoSize = true;
            this.radioMilk.Location = new System.Drawing.Point(146, 90);
            this.radioMilk.Name = "radioMilk";
            this.radioMilk.Size = new System.Drawing.Size(41, 17);
            this.radioMilk.TabIndex = 2;
            this.radioMilk.Text = "Tej";
            this.radioMilk.UseVisualStyleBackColor = true;
            this.radioMilk.CheckedChanged += new System.EventHandler(this.radioMilk_CheckedChanged);
            // 
            // radioIce
            // 
            this.radioIce.AutoSize = true;
            this.radioIce.Location = new System.Drawing.Point(146, 113);
            this.radioIce.Name = "radioIce";
            this.radioIce.Size = new System.Drawing.Size(73, 17);
            this.radioIce.TabIndex = 3;
            this.radioIce.Text = "Jégkocka";
            this.radioIce.UseVisualStyleBackColor = true;
            this.radioMilk.CheckedChanged += new System.EventHandler(this.radioIce_CheckedChanged);
            // 
            // radioTea
            // 
            this.radioTea.AutoSize = true;
            this.radioTea.Location = new System.Drawing.Point(51, 66);
            this.radioTea.Name = "radioTea";
            this.radioTea.Size = new System.Drawing.Size(44, 17);
            this.radioTea.TabIndex = 4;
            this.radioTea.TabStop = true;
            this.radioTea.Text = "Tea";
            this.radioTea.UseVisualStyleBackColor = true;
            this.radioTea.CheckedChanged += new System.EventHandler(this.radioTea_CheckedChanged);
            // 
            // radioCoffe
            // 
            this.radioCoffe.AutoSize = true;
            this.radioCoffe.Location = new System.Drawing.Point(51, 90);
            this.radioCoffe.Name = "radioCoffe";
            this.radioCoffe.Size = new System.Drawing.Size(50, 17);
            this.radioCoffe.TabIndex = 5;
            this.radioCoffe.TabStop = true;
            this.radioCoffe.Text = "Kave";
            this.radioCoffe.UseVisualStyleBackColor = true;
            this.radioCoffe.CheckedChanged += new System.EventHandler(this.radioCoffe_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(143, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Extrak";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(48, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Italok";
            // 
            // buttonPay
            // 
            this.buttonPay.Location = new System.Drawing.Point(51, 265);
            this.buttonPay.Name = "buttonPay";
            this.buttonPay.Size = new System.Drawing.Size(75, 23);
            this.buttonPay.TabIndex = 9;
            this.buttonPay.Text = "Fizetés";
            this.buttonPay.UseVisualStyleBackColor = true;
            this.label1.Click += new System.EventHandler(this.buttonPay_Click);
            // 
            // radioSzörp
            // 
            this.radioSzörp.AutoSize = true;
            this.radioSzörp.Location = new System.Drawing.Point(226, 91);
            this.radioSzörp.Name = "radioSzörp";
            this.radioSzörp.Size = new System.Drawing.Size(53, 17);
            this.radioSzörp.TabIndex = 10;
            this.radioSzörp.Text = "Szörp";
            this.radioSzörp.UseVisualStyleBackColor = true;
            this.radioSzörp.CheckedChanged += new System.EventHandler(this.radioSzörp_CheckedChanged_1);
            // 
            // checkCitrom
            // 
            this.checkCitrom.AutoSize = true;
            this.checkCitrom.Location = new System.Drawing.Point(226, 66);
            this.checkCitrom.Name = "checkCitrom";
            this.checkCitrom.Size = new System.Drawing.Size(55, 17);
            this.checkCitrom.TabIndex = 11;
            this.checkCitrom.Text = "Citrom";
            this.checkCitrom.UseVisualStyleBackColor = true;
            this.checkCitrom.CheckedChanged += new System.EventHandler(this.checkCitrom_Click);
            // 
            // radioWater
            // 
            this.radioWater.AutoSize = true;
            this.radioWater.Location = new System.Drawing.Point(51, 113);
            this.radioWater.Name = "radioWater";
            this.radioWater.Size = new System.Drawing.Size(39, 17);
            this.radioWater.TabIndex = 12;
            this.radioWater.TabStop = true;
            this.radioWater.Text = "Viz";
            this.radioWater.UseVisualStyleBackColor = true;
            this.radioWater.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.radioWater);
            this.Controls.Add(this.checkCitrom);
            this.Controls.Add(this.radioSzörp);
            this.Controls.Add(this.buttonPay);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.radioCoffe);
            this.Controls.Add(this.radioTea);
            this.Controls.Add(this.radioIce);
            this.Controls.Add(this.radioMilk);
            this.Controls.Add(this.radioCukor);
            this.Controls.Add(this.buttonExit);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.CheckBox radioCukor;
        private System.Windows.Forms.CheckBox radioMilk;
        private System.Windows.Forms.CheckBox radioIce;
        private System.Windows.Forms.RadioButton radioTea;
        private System.Windows.Forms.RadioButton radioCoffe;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button buttonPay;
        private System.Windows.Forms.CheckBox radioSzörp;
        private System.Windows.Forms.CheckBox checkCitrom;
        private System.Windows.Forms.RadioButton radioWater;
    }
}

