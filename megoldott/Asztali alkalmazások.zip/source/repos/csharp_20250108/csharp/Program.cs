﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace csharp
{
    class Szakasz
    {
        public double hossz;
        public int emelkedes, lejtes;
        public string indPont, vegPont, pecsetHely;
        
        public Szakasz(string egysor)
        {
            
            string[] darabok = egysor.Split(';');
            indPont = darabok[0];
            vegPont = darabok[1];
            hossz = double.Parse(darabok[2]);
            emelkedes = int.Parse(darabok[3]);
            lejtes = int.Parse(darabok[4]);
            pecsetHely = darabok[5];
            
        }
    }
    class Program
    {
        static string[] beolvas;
        static int tfm;
        static List<Szakasz> szakaszok = new List<Szakasz>();

        static void Main(string[] args)
        {
            beolvasas();
            f3();
            f4();
            f5();
            Console.ReadKey();

        }

        static void beolvasas()
        {
            beolvas = File.ReadAllLines("kektura.csv");
            tfm = int.Parse(beolvas[0]);
            for (int i = 1; i < beolvas.Length; i++)
            {
                szakaszok.Add(new Szakasz(beolvas[i]));
            }
        }
        static void f3()
        {
            Console.WriteLine($"3. feladat: \nSzakaszok száma: {szakaszok.Count} db");
        }

        
        static void f4()
        {
            double osz = 0;
            foreach (var item in szakaszok)
            {
                osz += item.hossz;
            }
            Console.WriteLine($"4. feladat: \nA túra teljes hossza: {osz} km");
        }
        
        static void f5()
        {
            int min = 0;
            double minH = szakaszok[0].hossz;
            for (int i = 1; i < szakaszok.Count; i++)
            {
                if (szakaszok[i].hossz < minH)
                {
                    minH = szakaszok[i].hossz;
                    min = i;
                }
            }

            var legSzak = szakaszok[min];
            Console.WriteLine($"5. feladat: \n {legSzak.indPont} ");
        }


    }
}
