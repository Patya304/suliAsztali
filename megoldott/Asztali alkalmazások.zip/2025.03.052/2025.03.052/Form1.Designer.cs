﻿namespace _2025._03._052
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelColor = new System.Windows.Forms.Panel();
            this.SB_size = new System.Windows.Forms.HScrollBar();
            this.SB_red = new System.Windows.Forms.HScrollBar();
            this.label_red = new System.Windows.Forms.Label();
            this.label_green = new System.Windows.Forms.Label();
            this.SB_green = new System.Windows.Forms.HScrollBar();
            this.label_blue = new System.Windows.Forms.Label();
            this.SB_blue = new System.Windows.Forms.HScrollBar();
            this.label_oldal = new System.Windows.Forms.Label();
            this.nud_meret2 = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.nud_meret2)).BeginInit();
            this.SuspendLayout();
            // 
            // panelColor
            // 
            this.panelColor.BackColor = System.Drawing.Color.Black;
            this.panelColor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelColor.Location = new System.Drawing.Point(92, 97);
            this.panelColor.Name = "panelColor";
            this.panelColor.Size = new System.Drawing.Size(200, 168);
            this.panelColor.TabIndex = 0;
            // 
            // SB_size
            // 
            this.SB_size.LargeChange = 1;
            this.SB_size.Location = new System.Drawing.Point(92, 57);
            this.SB_size.Maximum = 200;
            this.SB_size.Name = "SB_size";
            this.SB_size.Size = new System.Drawing.Size(287, 17);
            this.SB_size.TabIndex = 0;
            this.SB_size.Value = 200;
            this.SB_size.Scroll += new System.Windows.Forms.ScrollEventHandler(this.SB_size_Scroll);
            // 
            // SB_red
            // 
            this.SB_red.Location = new System.Drawing.Point(163, 325);
            this.SB_red.Name = "SB_red";
            this.SB_red.Size = new System.Drawing.Size(287, 17);
            this.SB_red.TabIndex = 1;
            this.SB_red.Scroll += new System.Windows.Forms.ScrollEventHandler(this.SB_red_Scroll);
            // 
            // label_red
            // 
            this.label_red.AutoSize = true;
            this.label_red.Location = new System.Drawing.Point(89, 325);
            this.label_red.Name = "label_red";
            this.label_red.Size = new System.Drawing.Size(30, 13);
            this.label_red.TabIndex = 2;
            this.label_red.Text = "Piros";
            // 
            // label_green
            // 
            this.label_green.AutoSize = true;
            this.label_green.Location = new System.Drawing.Point(89, 362);
            this.label_green.Name = "label_green";
            this.label_green.Size = new System.Drawing.Size(28, 13);
            this.label_green.TabIndex = 4;
            this.label_green.Text = "Zöld";
            // 
            // SB_green
            // 
            this.SB_green.Location = new System.Drawing.Point(163, 362);
            this.SB_green.Name = "SB_green";
            this.SB_green.Size = new System.Drawing.Size(287, 17);
            this.SB_green.TabIndex = 3;
            // 
            // label_blue
            // 
            this.label_blue.AutoSize = true;
            this.label_blue.Location = new System.Drawing.Point(89, 397);
            this.label_blue.Name = "label_blue";
            this.label_blue.Size = new System.Drawing.Size(26, 13);
            this.label_blue.TabIndex = 6;
            this.label_blue.Text = "Kék";
            // 
            // SB_blue
            // 
            this.SB_blue.Location = new System.Drawing.Point(163, 397);
            this.SB_blue.Name = "SB_blue";
            this.SB_blue.Size = new System.Drawing.Size(287, 17);
            this.SB_blue.TabIndex = 5;
            // 
            // label_oldal
            // 
            this.label_oldal.AutoSize = true;
            this.label_oldal.Location = new System.Drawing.Point(89, 24);
            this.label_oldal.Name = "label_oldal";
            this.label_oldal.Size = new System.Drawing.Size(91, 13);
            this.label_oldal.TabIndex = 7;
            this.label_oldal.Text = "A négyzet oldala: ";
            // 
            // nud_meret2
            // 
            this.nud_meret2.Location = new System.Drawing.Point(186, 22);
            this.nud_meret2.Maximum = new decimal(new int[] {
            200,
            0,
            0,
            0});
            this.nud_meret2.Name = "nud_meret2";
            this.nud_meret2.Size = new System.Drawing.Size(120, 20);
            this.nud_meret2.TabIndex = 9;
            this.nud_meret2.Value = new decimal(new int[] {
            200,
            0,
            0,
            0});
            this.nud_meret2.ValueChanged += new System.EventHandler(this.nud_meret2_ValueChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.nud_meret2);
            this.Controls.Add(this.label_oldal);
            this.Controls.Add(this.label_blue);
            this.Controls.Add(this.SB_blue);
            this.Controls.Add(this.label_green);
            this.Controls.Add(this.SB_green);
            this.Controls.Add(this.label_red);
            this.Controls.Add(this.SB_red);
            this.Controls.Add(this.SB_size);
            this.Controls.Add(this.panelColor);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.nud_meret2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panelColor;
        private System.Windows.Forms.HScrollBar SB_size;
        private System.Windows.Forms.HScrollBar SB_red;
        private System.Windows.Forms.Label label_red;
        private System.Windows.Forms.Label label_green;
        private System.Windows.Forms.HScrollBar SB_green;
        private System.Windows.Forms.Label label_blue;
        private System.Windows.Forms.HScrollBar SB_blue;
        private System.Windows.Forms.Label label_oldal;
        private System.Windows.Forms.NumericUpDown nud_meret2;
    }
}

