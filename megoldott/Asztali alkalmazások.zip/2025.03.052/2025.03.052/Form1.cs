﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace _2025._03._052
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }

        private void SB_size_Scroll(object sender, ScrollEventArgs e)
        {
            nud_meret2.Value = SB_size.Value;
            panelColor.Width = SB_size.Value;
            panelColor.Height = SB_size.Value;
        }

        private void nud_meret2_ValueChanged(object sender, EventArgs e)
        {
            SB_size.Value = (int)nud_meret2.Value;
            panelColor.Width = SB_size.Value;
            panelColor.Height = SB_size.Value;
        }

        private void SB_red_Scroll(object sender, ScrollEventArgs e)
        {
            panelColor.BackColor = Color.FromArgb(SB_red.Value, SB_green.Value, SB_blue.Value);
        }
    }
}