﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace _2536
{
    public partial class Form1 : Form
    {
        List<string> adatok = new List<string>();

        public Form1()
        {
            InitializeComponent();
            saveFileDialog1.DefaultExt = "txt";
            saveFileDialog1.Title = "Add meg mentés helyét";
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                File.WriteAllLines(saveFileDialog1.FileName, adatok);
            }
        }

        private void btnRead_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                adatok = new List<string>(File.ReadAllLines(openFileDialog1.FileName));
                listBox1.Items.Clear();
                listBox1.Items.AddRange(adatok.ToArray());
            }
        }
    }
}
