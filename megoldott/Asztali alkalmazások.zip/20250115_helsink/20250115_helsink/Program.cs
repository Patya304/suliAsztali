﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace _20250115_helsink
{
    class Olimpia
    {
        public string sport, versenyszam;
        public int helyezes, pont;

        public Olimpia(string adat)
        {
            string[] darabok = adat.Split(' ');
            helyezes = int.Parse(darabok[0]);
            pont = int.Parse(darabok[1]);
            sport = darabok[2];
            versenyszam = darabok[3];
        }
    }
    class Program
    {
        static List<Olimpia> jatekok = new List<Olimpia>();
        static void Main(string[] args)
        {
            f2();
            f3();
            f4();
            f5();
            f6();
            /*f7();*/
            f8();
            Console.ReadKey();
        }

        static void f2()
        {
            string[] Beolvas = File.ReadAllLines("helsinki.txt");
            foreach (var item in Beolvas)
            {
                jatekok.Add(new Olimpia(item));
            }
        }

        static void f3()
        {
            Console.WriteLine($"3. feladat: \nPontszerző helyezések száma: {jatekok.Count()}");
        }

        static void f4()
        {
            int Arany = 0;
            int Ezust = 0;
            int Bronz = 0;
            foreach (var item in jatekok)
            {
                if (item.helyezes == 1)
                {
                    Arany += 1;
                }
                else if (item.helyezes == 2)
                {
                    Ezust += 1;
                }
                else if (item.helyezes == 3)
                {
                    Bronz += 1;
                }
            }
            Console.WriteLine($"\n4. feladat: \nArany: {Arany} \nEzüst: {Ezust} \nBronz: {Bronz} \nÖsszesen: {Arany + Ezust + Bronz}");
        }

        static void f5()
        {
            int pontok = 0;
            foreach (var item in jatekok)
            {
                switch (item.helyezes)
                {
                    case 1:
                        pontok += 7;
                        break;
                    case 2:
                        pontok += 5;
                        break;
                    case 3:
                        pontok += 4;
                        break;
                    case 4:
                        pontok += 3;
                        break;
                    case 5:
                        pontok += 2;
                        break;
                    case 6:
                        pontok += 1;
                        break;
                }
            }
            Console.WriteLine($"\n5. feladat: \nOlimpia pontok száma: {pontok}");
        }
        static void f6()
        {
            int uszas = 0; int torna = 0;
            foreach (var item in jatekok)
            {
                switch (item.sport)
                {
                    case "uszas":
                        uszas +=1;
                        break;

                    case "torna":
                        torna +=1;
                        break;
                }
            }
            if (uszas > torna)
            {
                Console.WriteLine("$6. feladat: \nUszas sportágban szereztek több érmet.");
            }
            else if (uszas < torna)
            {
                Console.WriteLine($"\n6. feladat: \nTorna sportágban szereztek több érmet.");
            }
            else
            {
                Console.WriteLine($"\n6. feladat: \nEgyenlő volt az érmek száma.");
            }
        }
        /*static void f7()
        {

        }*/
        static void f8()
        {
            /*
        static void f4()
        {
            int Arany = 0;
            int Ezust = 0;
            int Bronz = 0;
            sport, sv =  vs
            foreach (var item in jatekok)
            {
                if (item.helyezes == 1)
                {
                    Arany += 1;
                }
                else if (item.helyezes == 2)
                {
                    Ezust += 1;
                }
                else if (item.helyezes == 3)
                {
                    Bronz += 1;
                }
            }
            Console.WriteLine($"\n4. feladat: \nArany: {Arany} \nEzüst: {Ezust} \nBronz: {Bronz} \nÖsszesen: {Arany + Ezust + Bronz}");
        }
             */
            int sportolok = 0;
            foreach (var item in jatekok)
            {

            }
        }
    }
}
